import React from 'react';
import PropTypes, { any } from 'prop-types';

class BarraNav extends React.Component {
    render() {
        return (
            <div className="barraNav-container1">
                <div className="barraNav-container3">
                    <img
                        alt={this.props.imageAlt}
                        src={this.props.imageSrc}
                        className="barraNav-image"
                    />
                    <div className="barraNav-container4">
                        <p className="barraNav-user">Juan Perez</p>
                        <p className="barraNav-perfil">Estudiante</p>
                    </div>
                </div>
                
                <div className="barraNav-container5">
                    
                    <div className='barraNav-container7'>
                        <button type="button" className="barraNav-inicio">
                            <span>
                                {this.props.text ?? (any)}
                            </span>
                        </button>
                        <button type="button" className="barraNav-selRuta">
                            <span>
                                {this.props.text1 ?? (any)}
                            </span>
                        </button>
                        <button type="button" className="barraNav-selParada">
                            <span>
                                {this.props.text2 ?? (any)}
                            </span>
                        </button>
                        <button type="button" className="barraNav-estadoRuta">
                            <span>
                                {this.props.text3 ?? (any)}
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        );
    }
}

BarraNav.defaultProps = {
    text2: undefined,
    imageSrc: 'https://cdn-icons-png.flaticon.com/512/8920/8920554.png',
    text3: undefined,
    text: undefined,
    text1: undefined,
    text5: undefined,
    imageAlt: 'estudiante',
    text4: undefined,
};

BarraNav.propTypes = {
    text2: PropTypes.element,
    imageSrc: PropTypes.string,
    text3: PropTypes.element,
    text: PropTypes.element,
    text1: PropTypes.element,
    text5: PropTypes.element,
    imageAlt: PropTypes.string,
    text4: PropTypes.element,
};

export default BarraNav;

