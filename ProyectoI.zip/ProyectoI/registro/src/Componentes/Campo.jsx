import React from 'react';

class Campo extends React.Component{
    render(){
        const{titulo, texto} = this.props;
        return(
            <div className="container5">
                <label className="campo-titulo">{titulo}</label>
                <input
                    required="true"
                    placeholder={texto}
                    className="campo-texto"
                />
            </div>
        );
    }
}

export default Campo;